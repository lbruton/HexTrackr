Version: 3.04.77
Date: 2025-08-15
Agent: GPT
Summary: Exposed item count element in pagination for global state access.
