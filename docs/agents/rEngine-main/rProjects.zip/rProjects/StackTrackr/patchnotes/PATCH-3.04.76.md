Version: 3.04.76
Date: 2025-08-15
Agent: GPT
Summary: Added inventory table item counter with muted styling and documented usage.
