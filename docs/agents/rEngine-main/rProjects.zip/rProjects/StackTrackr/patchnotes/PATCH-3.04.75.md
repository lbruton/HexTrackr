Version: 3.04.75
Date: 2025-08-14
Agent: GPT
Summary: Added debug modal with log history and enhanced import/export debugging.
