Version: 3.04.89
Date: 2025-08-18
Agent: gpt-4o
Summary: Modernized rows-per-page dropdown with compact button styling and aligned it to the table footer's right edge while keeping the item counter on the left.
