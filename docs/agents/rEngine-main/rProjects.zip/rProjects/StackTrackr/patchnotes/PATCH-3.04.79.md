Version: 3.04.79
Date: 2025-08-15
Agent: GPT
Summary: Wrapped Node exports with environment check and exposed fuzzy-search utilities to browser.
