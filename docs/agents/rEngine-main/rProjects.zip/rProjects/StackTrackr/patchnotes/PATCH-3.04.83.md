Version: 3.04.83
Date: 2025-08-16
Agent: GPT-4o
Summary: Load grouped-name-chips test only during development and add Node dev server to serve JS with proper MIME type.
