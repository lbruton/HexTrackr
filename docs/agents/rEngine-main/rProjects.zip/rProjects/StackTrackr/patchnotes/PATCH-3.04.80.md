Version: 3.04.80
Date: 2025-08-15
Agent: GPT
Summary: Aligned fuzzy-search threshold defaults and documentation.
