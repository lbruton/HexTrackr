Version: 3.04.91
Date: 2025-08-19
Agent: GPT
Summary: Added chip text color variable and contrast helper to ensure filter chips remain legible across themes.
