Version: 3.04.88
Date: 2025-08-18
Agent: gpt-4o
Summary: Added emphasized styling for table item counter with stronger font weight, larger size, and subtle background; updated HTML wrapper and style guide.
