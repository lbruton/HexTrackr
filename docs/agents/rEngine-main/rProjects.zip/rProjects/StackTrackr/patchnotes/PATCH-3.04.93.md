Version: 3.04.93
Date: 2025-08-20
Agent: gpt-4o
Summary: Centralized type and metal filter resets within clearAllFilters and streamlined clear button to call the helper directly.
