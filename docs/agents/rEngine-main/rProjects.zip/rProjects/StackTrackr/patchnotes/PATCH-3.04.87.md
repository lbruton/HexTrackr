Version: 3.04.87
Date: 2025-08-17
Agent: gpt-4o
Summary: Moved rows-per-page selector below inventory table, wrapping it with item count in a flexbox container and removed old control group.
