Version: 3.04.74
Date: 2025-08-14
Agent: GPT
Summary: Restored global access for CSV import/export utilities and fixed CSV notes handling.
