Version: 3.04.92
Date: 2025-08-19
Agent: gpt-4o
Summary: Unified search control buttons under .btn.success, removed obsolete square class, and scoped table icon-button styles to preserve consistent sizing.
