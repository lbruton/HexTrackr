Version: 3.04.85
Date: 2025-08-17
Agent: GPT-4.1
Summary: Allow slash in item name sanitization, extended stripNonAlphanumeric helper, and added test for slash preservation.
