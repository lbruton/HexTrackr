Version: 3.04.90
Date: 2025-08-18
Agent: gpt-4-1
Summary: Reordered filter controls before chip row and added spacing for clear separation; selectors and pagination verified.
