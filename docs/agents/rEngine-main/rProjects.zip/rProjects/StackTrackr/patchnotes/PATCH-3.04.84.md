Version: 3.04.84
Date: 2025-08-16
Agent: GPT-4o
Summary: Render active filter chips on initial load by calling renderActiveFilters after renderTable in init.js.
