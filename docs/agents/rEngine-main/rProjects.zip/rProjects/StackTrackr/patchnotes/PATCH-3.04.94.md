Version: 3.04.94
Date: 2025-08-20
Agent: GPT
Summary: Render active filter chips automatically after imports by calling renderActiveFilters after renderTable.
