Version: 3.04.81
Date: 2025-08-15
Agent: GPT
Summary: Exposed checkFileSize and MAX_LOCAL_FILE_SIZE globals and added validation script.

