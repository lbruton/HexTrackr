/* eslint-disable no-unused-vars */
/* global window document localStorage sessionStorage fetch console setTimeout clearTimeout setInterval clearInterval alert confirm prompt btoa atob URL Blob File FileReader FormData location history navigator XMLHttpRequest */
/* global bootstrap Papa agGrid ApexCharts DOMPurify Chart jsPDF html2canvas */
