# Contribution Guidelines

We welcome contributions to HexTrackr! Please follow these guidelines to ensure a smooth process.

## Code Style

- Follow the rules defined in the `.eslintrc.js` file.
- Use `npm run lint` to check for issues.
